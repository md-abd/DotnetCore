﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class ReportManagement
    {
        [Key]
        [Display(Name = "Batch Code")]
        public string Batch_Code { get; set; }
    }
}