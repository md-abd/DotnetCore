﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class ReportSubmission
    {
        [Key]
        [Display(Name = "Batch Code")]
        public string Batch_Code { get; set; }
        [Display(Name = "Faculty Id")]
        public string Faculty_Id { get; set; }
        [Display(Name = "Submitted Weekly Reports")]
        public string Submitted_Weekly_Reports { get; set; }
        [Display(Name = "Mock Tests Conducted")]
        public string Mock_Tests_Conducted { get; set; }

        [Display(Name = "Innovation Project Title")]
        public string Innovation_Project_Title { get; set; }
        [Display(Name = "Innovation Project Description")]


        public string Innovation_Project_Description { get; set; }
        [Display(Name = "Project Status")]
        public string Project_Status { get; set; }

    }
}