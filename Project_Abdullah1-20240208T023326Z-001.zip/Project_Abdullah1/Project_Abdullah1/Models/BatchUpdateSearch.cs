﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class BatchUpdateSearch
    {
        [Key]
        [Display(Name = "ID")]
        public int ID { get; set; }
        [Display(Name = "Batch_id")]
        public int Batch_id { get; set; }
        [Display(Name = "Faculty_Id")]
        public int Faculty_Id { get; set; }
        [Display(Name = "Batch_Start_Date")]
        public string Batch_Start_Date { get; set; }
        [Display(Name = "Batch_End_Date")]
        public string Batch_End_Date { get; set; }
        [Display(Name = "Batch_Closure_Date")]
        public string Batch_Closure_Date { get; set; }
    }
}
