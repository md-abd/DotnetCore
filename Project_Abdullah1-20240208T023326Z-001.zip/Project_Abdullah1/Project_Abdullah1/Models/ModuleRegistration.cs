﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class ModuleRegistration
    {
        [Key]
        [Display(Name = "M_ID")]
        public int M_ID { get; set; }
        [Display(Name = "Technology_Name")]
        public string Technology_Name { get; set; }
        [Display(Name = "Domain_Description")]
        public string Domain_Description { get; set; }
        [Display(Name = "Module_Type")]
        public string Module_Type { get; set; }
        [Display(Name = "Duration")]
        public string Duration { get; set; }
    }
}

