﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class FacultyCertification
    {
        [Key]
        [Display(Name = "Faculty_ID")]
        public int Faculty_ID { get; set; }
        [Display(Name = "Faculty Skill")]
        public string Faculty_Skill { get; set; }
        [Display(Name = "Faculty Skill")]
        public string Faculty_Skill1 { get; set; }
        [Display(Name = "Faculty Skill")]
        public string Faculty_Skill2 { get; set; }
        [Display(Name = "Certification Title")]
        public string Certification_Title { get; set; }

    }
}
