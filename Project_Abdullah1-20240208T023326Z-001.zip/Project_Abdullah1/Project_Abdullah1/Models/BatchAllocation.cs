﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class BatchAllocation
    {
        [Key]
        [Display(Name = "Domain Id")]
        public int Domain_ID { get; set; }
        [Display(Name = "Faculty Id")]
        public int Faculty_ID { get; set; }
        [Display(Name = "Batch Start Date ")]
        public string Batch_start_date { get; set; }
        [Display(Name = "Batch End Date ")]
        public string Batch_end_date { get; set; }
    }
}
