﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class FacultySearch
    {

        [Key]
        [Display(Name = "Faculty Id")]
        public string Faculty_id { get; set; }
    }
}
