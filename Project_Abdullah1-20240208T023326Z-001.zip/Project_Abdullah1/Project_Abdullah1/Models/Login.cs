﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class Login
    {
        [Key]
        [Display(Name = "id")]
        public int id { get; set; }
        [Required(ErrorMessage = "Enter Faculty Name")]
        [Display(Name = "UserName ")]
        public string UserName { get; set; }
        [Display(Name = "Password")]
        public string Password { get; set; }
    }
}