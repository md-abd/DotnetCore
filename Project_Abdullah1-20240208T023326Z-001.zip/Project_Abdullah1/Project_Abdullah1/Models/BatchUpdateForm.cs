﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class BatchUpdateForm
    {

        [Key]
        [Display(Name = "Faculty Id")]
        public int Faculty_ID { get; set; }
    }
}