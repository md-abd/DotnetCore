﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Project_Abdullah1.Models
{
    public class Baseline1 : DbContext
    {
        public Baseline1(DbContextOptions<Baseline1> options) : base(options) { }
        public DbSet<FacultyInformation> FacultyInformation { get; set; }
        public DbSet<FacultyCertification> FacultyCertification { get; set; }
        public DbSet<ModuleRegistration> ModuleRegistration { get; set; }
        public DbSet<BatchAllocation> BatchAllocation { get; set; }
        public DbSet<BatchUpdateForm> BatchUpdateForm { get; set; }
        public DbSet<BatchUpdateSearch> BatchUpdateSearch { get; set; }
        public DbSet<BatchInfoTable> BatchInfoTable { get; set; }
        public DbSet<ReportManagement> ReportManagement { get; set; }
        public DbSet<ReportSubmission> ReportSubmission { get; set; }
        public DbSet<FacultySearch> FacultySearch { get; set; }
        public DbSet<BatchScreen> BatchScreen { get; set; }
        public DbSet<Login> Login { get; set; }
    }
}

