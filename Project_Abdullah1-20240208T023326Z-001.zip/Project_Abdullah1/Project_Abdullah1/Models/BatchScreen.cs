﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Project_Abdullah1.Models
{
    public class BatchScreen
    {
        [Key]
        [Display(Name = "F_ID")]
        public int F_ID { get; set; }
        [Display(Name = "Batch_Id")]
        public int Batch_Id { get; set; }
        [Display(Name = "Feedback_Percentage ")]
        public int Feedback_Percentage { get; set; }
        [Display(Name = "Extra_Hours ")]
        public int Extra_Hours { get; set; }
        [Display(Name = "BatchPass_Percentage")]
        public int BatchPass_Percentage { get; set; }
        [Display(Name = "Faculty_Upgrade")]
        public string Faculty_Upgrade { get; set; }

        [Display(Name = "Handson_Completion")]
        public int Handson_Completion { get; set; }
    }
}

