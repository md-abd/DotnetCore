﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Project_Abdullah1.Models
{
    public class FacultyInformation
    {
        [Key]
        [Display(Name = "Faculty Id")]
        public int Faculty_ID { get; set; }
        [Required(ErrorMessage = "Enter Faculty Name")]
        [Display(Name = "Faculty Name ")]
        public string Faculty_Name { get; set; }
        [Display(Name = "Highest Qualification")]
        public string Highest_Qualification { get; set; }
        [Display(Name = "Year of Experience")]
        public string Year_of_Experience { get; set; }
        [Display(Name = "Contact")]
        public string Contact { get; set; }
        [Display(Name = "Faculty Email")]

        public string Faculty_Email { get; set; }
        [Display(Name = "Address")]
        public string Address { get; set; }
    }
}